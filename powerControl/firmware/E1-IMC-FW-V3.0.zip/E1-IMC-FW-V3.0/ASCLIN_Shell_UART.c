/*********************************************************************************************************************/
/*-----------------------------------------------------Includes------------------------------------------------------*/
/*********************************************************************************************************************/
#include "ASCLIN_Shell_UART.h"
#include "Ifx_Types.h"
#include "IfxAsclin_Asc.h"
#include "Ifx_Shell.h"
#include "Ifx_Console.h"
#include "IfxPort.h"
#include "Profet_PMM.h"
#include "bsp.h"
#include "Ifx_Assert.h"
#include "IfxDma_Dma.h"

/*********************************************************************************************************************/
/*------------------------------------------------------Macros-------------------------------------------------------*/
/*********************************************************************************************************************/
/* Communication parameters */
#define ISR_PRIORITY_ASCLIN_TX      8                                       /* Priority for interrupt ISR Transmit  */
#define ISR_PRIORITY_ASCLIN_RX      4                                       /* Priority for interrupt ISR Receive   */
#define ISR_PRIORITY_ASCLIN_ER      12                                      /* Priority for interrupt ISR Errors    */
#define ISR_PRIORITY_BACKUP_TX      9                                       /* Priority for interrupt ISR Transmit  */
#define ISR_PRIORITY_BACKUP_RX      5                                       /* Priority for interrupt ISR Receive   */
#define ISR_PRIORITY_BACKUP_ER      13                                      /* Priority for interrupt ISR Errors    */
#define ASC_TX_BUFFER_SIZE          256                                     /* Define the TX buffer size in byte    */
#define ASC_RX_BUFFER_SIZE          256                                     /* Define the RX buffer size in byte    */
#define ASC_BAUDRATE                115200                                  /* Define the UART baud rate            */


/* LED and Switch Pins */
#define LED1                        &MODULE_P10,4                           /* LED Port Pin                         */
#define LED2                        &MODULE_P02,3                           /* LED Port Pin                         */
#define LED3                        &MODULE_P10,1                           /* LED Port Pin                         */
#define LED4                        &MODULE_P10,2                           /* LED Port Pin                         */

#define IN1                         &MODULE_P02,7                           /* LED Port Pin                         */
#define IN2                         &MODULE_P10,5                           /* LED Port Pin                         */
#define IN3                         &MODULE_P10,3                           /* LED Port Pin                         */
#define IN4                         &MODULE_P02,1                           /* LED Port Pin                         */

/* PROFET PMM MODULE */
  // #define PMM


/* Shell commands and help descriptions */
#define COMMAND_INFO                "info"
#define COMMAND_INFO_HELP_TEXT      "   : Show the example's info"
#define COMMAND_TOGGLE              "toggle"
#define COMMAND_TOGGLE_HELP_TEXT    "   : Command to toggle LED" ENDLINE \
                                    "         The correct syntax for this command is" ENDLINE \
                                    "         '" COMMAND_TOGGLE " [1]'"
#define COMMAND_HELP                "help"
#define COMMAND_HELP_HELP_TEXT      "   : Show this help list"

#define COMMAND_CYCLE               "cycle"
#define COMMAND_CYCLE_HELP_TEXT     "   : Power Cycle a channel on the PMM"

#define COMMAND_SET                 "set"
#define COMMAND_SET_HELP_TEXT       "   : Set a power channel output ON or OFF"

#define COMMAND_STATUS              "status"
#define COMMAND_STATUS_HELP_TEXT    "   : Display CSV format status of connected PMMs"

#define COMMAND_VSTATUS             "vstatus"
#define COMMAND_VSTATUS_HELP_TEXT   "   : Display human readable format status of connected PMMs"


/*********************************************************************************************************************/
/*------------------------------------------------Function Prototypes------------------------------------------------*/
/*********************************************************************************************************************/
void initHSS(void);
void initSerialInterface(void);
void initBackupInterface(void);
void printInfo(IfxStdIf_DPipe *io);
boolean HSSStatus(pchar args, void *data, IfxStdIf_DPipe *io);
boolean HSSvStatus(pchar args, void *data, IfxStdIf_DPipe *io);
boolean setHSS(pchar args, void *data, IfxStdIf_DPipe *io);
boolean cycleHSS(pchar args, void *data, IfxStdIf_DPipe *io);
boolean printShellInfo(pchar args, void *data, IfxStdIf_DPipe *io);
boolean toggleHSSShell(pchar args, void *data, IfxStdIf_DPipe *io);
static void delay(uint32 ms);
/*********************************************************************************************************************/
/*-------------------------------------------------Global variables--------------------------------------------------*/
/*********************************************************************************************************************/
IfxStdIf_DPipe  g_ascStandardInterface;                                     /* Standard interface object            */
IfxAsclin_Asc   g_asclin;                                                   /* ASCLIN module object                 */
Ifx_Shell       g_shellInterface;                                           /* Shell interface object               */

IfxStdIf_DPipe  g_ascBackupInterface;                                     /* Standard interface object            */
IfxAsclin_Asc   g_backup;                                                   /* ASCLIN module object                 */
Ifx_Shell       g_backupInterface;                                           /* Shell interface object               */
/* The transfer buffers allocate memory for the data itself and for FIFO runtime variables.
 * 8 more bytes have to be added to ensure a proper circular buffer handling independent from
 * the address to which the buffers have been located.
 */
uint8 g_uartTxBuffer[ASC_TX_BUFFER_SIZE + sizeof(Ifx_Fifo) + 8];
uint8 g_uartRxBuffer[ASC_RX_BUFFER_SIZE + sizeof(Ifx_Fifo) + 8];

uint8 g_backupTxBuffer[ASC_TX_BUFFER_SIZE + sizeof(Ifx_Fifo) + 8];
uint8 g_backupRxBuffer[ASC_RX_BUFFER_SIZE + sizeof(Ifx_Fifo) + 8];

/* Array that stores the supported Shell commands */
const Ifx_Shell_Command g_shellCommands[] = {
    {COMMAND_INFO,   COMMAND_INFO_HELP_TEXT,    &g_shellInterface, &printShellInfo     },
    {COMMAND_TOGGLE, COMMAND_TOGGLE_HELP_TEXT,  &g_shellInterface, &toggleHSSShell    },
    {COMMAND_HELP,   COMMAND_HELP_HELP_TEXT,    &g_shellInterface, &Ifx_Shell_showHelp },
    {COMMAND_STATUS,   COMMAND_STATUS_HELP_TEXT,    &g_shellInterface, &HSSStatus },
    {COMMAND_VSTATUS,   COMMAND_VSTATUS_HELP_TEXT,    &g_shellInterface, &HSSvStatus },
    {COMMAND_CYCLE,   COMMAND_CYCLE_HELP_TEXT,    &g_shellInterface, &cycleHSS },
    {COMMAND_SET,   COMMAND_SET_HELP_TEXT,    &g_shellInterface, &setHSS },
    IFX_SHELL_COMMAND_LIST_END
};


const Ifx_Shell_Command g_backupCommands[] = {
    {COMMAND_INFO,   COMMAND_INFO_HELP_TEXT,    &g_backupInterface, &printShellInfo     },
    {COMMAND_TOGGLE, COMMAND_TOGGLE_HELP_TEXT,  &g_backupInterface, &toggleHSSShell    },
    {COMMAND_HELP,   COMMAND_HELP_HELP_TEXT,    &g_backupInterface, &Ifx_Shell_showHelp },
    {COMMAND_STATUS,   COMMAND_STATUS_HELP_TEXT,    &g_backupInterface, &HSSStatus },
    {COMMAND_VSTATUS,   COMMAND_VSTATUS_HELP_TEXT,    &g_backupInterface, &HSSvStatus },
    {COMMAND_CYCLE,   COMMAND_CYCLE_HELP_TEXT,    &g_backupInterface, &cycleHSS },
    {COMMAND_SET,   COMMAND_SET_HELP_TEXT,    &g_backupInterface, &setHSS },
    IFX_SHELL_COMMAND_LIST_END
};


/*********************************************************************************************************************/
/*---------------------------------------------Function Implementations----------------------------------------------*/
/*********************************************************************************************************************/
/* Macro to define Interrupt Service Routine.
 * This macro makes following definitions:
 * 1) Define linker section as .intvec_tc<vector number>_<interrupt priority>.
 * 2) define compiler specific attribute for the interrupt functions.
 * 3) define the Interrupt service routine as ISR function.
 *
 * IFX_INTERRUPT(isr, vectabNum, priority)
 *  - isr: Name of the ISR function.
 *  - vectabNum: Vector table number.
 *  - priority: Interrupt priority. Refer Usage of Interrupt Macro for more details.
 */


/*********************************************************************************************************************/
/*--------------------------------------------- ISR----------------------------------------------*/
/*********************************************************************************************************************/
IFX_INTERRUPT(asc0TxISR, 0, ISR_PRIORITY_ASCLIN_TX);

void asc0TxISR(void)
{
    IfxStdIf_DPipe_onTransmit(&g_ascStandardInterface);
}

IFX_INTERRUPT(asc0RxISR, 0, ISR_PRIORITY_ASCLIN_RX);

void asc0RxISR(void)
{
    IfxStdIf_DPipe_onReceive(&g_ascStandardInterface);
}

IFX_INTERRUPT(asc0ErrISR, 0, ISR_PRIORITY_ASCLIN_ER);

void asc0ErrISR(void)
{
    IfxStdIf_DPipe_onError(&g_ascStandardInterface);
}


IFX_INTERRUPT(asc1TxISR, 0, ISR_PRIORITY_BACKUP_TX);

void asc1TxISR(void)
{
    IfxStdIf_DPipe_onTransmit(&g_ascBackupInterface);
}

IFX_INTERRUPT(asc1RxISR, 0, ISR_PRIORITY_BACKUP_RX);

void asc1RxISR(void)
{
    IfxStdIf_DPipe_onReceive(&g_ascBackupInterface);
}

IFX_INTERRUPT(asc1ErrISR, 0, ISR_PRIORITY_BACKUP_ER);

void asc1ErrISR(void)
{
    IfxStdIf_DPipe_onError(&g_ascBackupInterface);
}


/* Function to print info in the console */
void printInfo(IfxStdIf_DPipe *io)
{
    IfxStdIf_DPipe_print(io, ENDLINE);
    IfxStdIf_DPipe_print(io, "+-------------------------------------------------------------------+"ENDLINE);
    IfxStdIf_DPipe_print(io, "|        - E1 Buoy Instrument Management and Control V3.0   -         |"ENDLINE);
    IfxStdIf_DPipe_print(io, "+-------------------------------------------------------------------+"ENDLINE);

}

/* Function to show information about the example through the shell */
boolean printShellInfo(pchar args, void *data, IfxStdIf_DPipe *io)
{
    printInfo(io);
    return TRUE;
}

/* Function to toggle the LED */
boolean toggleHSSShell(pchar args, void *data, IfxStdIf_DPipe *io)
{
    switch (args[0]) {
        case '1':
            IfxPort_setPinState(LED1, IfxPort_State_toggled);
            IfxPort_setPinState(IN1, IfxPort_State_toggled);
            IfxStdIf_DPipe_print(io, "[+] TOGGLE CH 1" ENDLINE ENDLINE);
            break;
        case '2':
            IfxPort_setPinState(LED2, IfxPort_State_toggled);
            IfxPort_setPinState(IN2, IfxPort_State_toggled);
            IfxStdIf_DPipe_print(io, "[+] TOGGLE CH 2" ENDLINE ENDLINE);
            break;
        case '3':

            IfxPort_setPinState(LED3, IfxPort_State_toggled);
            IfxPort_setPinState(IN3, IfxPort_State_toggled);
            IfxStdIf_DPipe_print(io, "[+] TOGGLE CH 3" ENDLINE ENDLINE);
            break;

        case '4':
            IfxPort_setPinState(LED4, IfxPort_State_toggled);
            IfxPort_setPinState(IN4, IfxPort_State_toggled);
            IfxStdIf_DPipe_print(io, "[+] TOGGLE CH 4" ENDLINE ENDLINE);
            break;

        default:
        IfxStdIf_DPipe_print(io, "[-] ERR: CMD SYNTAX." ENDLINE \
                "SYNTAX USAGE: " ENDLINE "    '" COMMAND_TOGGLE " <int CHANNEL>'" ENDLINE);
        return FALSE; /* Returning false triggers a Shell command error */
    }
    return TRUE;
}

/* Function to initialize GPIO pins for the LED */
void initHSS(void)
{
    /* Initialize GPIO pins for the LED */
    IfxPort_setPinMode(LED1, IfxPort_Mode_outputPushPullGeneral);
    IfxPort_setPinMode(LED2, IfxPort_Mode_outputPushPullGeneral);
    IfxPort_setPinMode(LED3, IfxPort_Mode_outputPushPullGeneral);
    IfxPort_setPinMode(LED4, IfxPort_Mode_outputPushPullGeneral);

    IfxPort_setPinMode(IN1, IfxPort_Mode_outputPushPullGeneral);
    IfxPort_setPinMode(IN2, IfxPort_Mode_outputPushPullGeneral);
    IfxPort_setPinMode(IN3, IfxPort_Mode_outputPushPullGeneral);
    IfxPort_setPinMode(IN4, IfxPort_Mode_outputPushPullGeneral);


    IfxPort_setPinState(LED1, IfxPort_State_high);
    IfxPort_setPinState(LED2, IfxPort_State_high);
    IfxPort_setPinState(LED3, IfxPort_State_high);
    IfxPort_setPinState(LED4, IfxPort_State_high);

    /* Turn off the LED */
    IfxPort_setPinState(IN1, IfxPort_State_high);
    IfxPort_setPinState(IN2, IfxPort_State_high);
    IfxPort_setPinState(IN3, IfxPort_State_high);
    IfxPort_setPinState(IN4, IfxPort_State_high);
}


boolean setHSS(pchar args, void *data, IfxStdIf_DPipe *io) {
    return TRUE;
}

boolean cycleHSS(pchar args, void *data, IfxStdIf_DPipe *io) {

    switch (args[0]) {
        case '1':
            IfxPort_setPinState(LED1, IfxPort_State_low);
            IfxPort_setPinState(IN1, IfxPort_State_low);
            delay(1000);
            delay(1000);
            delay(1000);
            delay(1000);
            delay(1000);
            IfxPort_setPinState(LED1, IfxPort_State_high);
            IfxPort_setPinState(IN1, IfxPort_State_high);
            IfxStdIf_DPipe_print(io, "[+] CYCLE CH 1" ENDLINE ENDLINE);
            break;
        case '2':
            IfxPort_setPinState(LED2, IfxPort_State_low);
            IfxPort_setPinState(IN2, IfxPort_State_low);
            delay(1000);
            delay(1000);
            delay(1000);
            delay(1000);
            delay(1000);
            IfxPort_setPinState(LED2, IfxPort_State_high);
            IfxPort_setPinState(IN2, IfxPort_State_high);
            IfxStdIf_DPipe_print(io, "[+] CYCLE CH 2" ENDLINE ENDLINE);
            break;
        case '3':
            IfxPort_setPinState(LED3, IfxPort_State_low);
            IfxPort_setPinState(IN3, IfxPort_State_low);
            delay(1000);
            delay(1000);
            delay(1000);
            delay(1000);
            delay(1000);
            IfxPort_setPinState(LED3, IfxPort_State_high);
            IfxPort_setPinState(IN3, IfxPort_State_high);
            IfxStdIf_DPipe_print(io, "[+] CYCLE CH 3" ENDLINE ENDLINE);
            break;
        case '4':
            IfxPort_setPinState(LED4, IfxPort_State_low);
            IfxPort_setPinState(IN4, IfxPort_State_low);
            delay(1000);
            delay(1000);
            delay(1000);
            delay(1000);
            delay(1000);
            IfxPort_setPinState(LED4, IfxPort_State_high);
            IfxPort_setPinState(IN4, IfxPort_State_high);
            IfxStdIf_DPipe_print(io, "[+] CYCLE CH 4" ENDLINE ENDLINE);
            break;

        default:
            //IfxPort_setPinState(LED1, IfxPort_State_low);
            //IfxPort_setPinState(LED2, IfxPort_State_low);
            //IfxPort_setPinState(LED3, IfxPort_State_low);
            //IfxPort_setPinState(LED4, IfxPort_State_low);
            IfxStdIf_DPipe_print(io, "[-] ERR: CMD SYNTAX." ENDLINE \
                    "SYNTAX USAGE: " ENDLINE "    '" COMMAND_CYCLE " <int CHANNEL>'" ENDLINE);
            return FALSE; /* Returning false triggers a Shell command error */
    }
    return TRUE;
}


static void delay(uint32 ms) {

    sint32 fSys = IfxStm_getFrequency(&MODULE_STM0);
    Ifx_TickTime wait_ms = (fSys / (1000 / ms));
    wait(wait_ms);
}

boolean HSSStatus(pchar args, void *data, IfxStdIf_DPipe *io) {
    return TRUE;
}

boolean HSSvStatus(pchar args, void *data, IfxStdIf_DPipe *io) {
    return TRUE;
}


void initBackupInterface(void) {

    IfxAsclin_Asc_Config backupAscConf;

    /* Set default configurations */
    IfxAsclin_Asc_initModuleConfig(&backupAscConf, &MODULE_ASCLIN1); /* Initialize the structure with default values      */

    /* Set the desired baud rate */
    backupAscConf.baudrate.baudrate = ASC_BAUDRATE;                                   /* Set the baud rate in bit/s       */
    backupAscConf.baudrate.oversampling = IfxAsclin_OversamplingFactor_16;            /* Set the oversampling factor      */

    /* Configure the sampling mode */
    backupAscConf.bitTiming.medianFilter = IfxAsclin_SamplesPerBit_three;             /* Set the number of samples per bit*/
    backupAscConf.bitTiming.samplePointPosition = IfxAsclin_SamplePointPosition_8;    /* Set the first sample position    */

    /* ISR priorities and interrupt target */
    backupAscConf.interrupt.txPriority = ISR_PRIORITY_BACKUP_TX;  /* Set the interrupt priority for TX events             */
    backupAscConf.interrupt.rxPriority = ISR_PRIORITY_BACKUP_RX;  /* Set the interrupt priority for RX events             */
    backupAscConf.interrupt.erPriority = ISR_PRIORITY_BACKUP_ER;  /* Set the interrupt priority for Error events          */
    backupAscConf.interrupt.typeOfService = IfxSrc_Tos_cpu0;


    /* Pin configuration */
    const IfxAsclin_Asc_Pins backupPins = {
            .cts        = NULL_PTR,                         /* CTS pin not used                                     */
            .ctsMode    = IfxPort_InputMode_pullUp,
            .rx         = &IfxAsclin1_RXA_P15_1_IN,        /* Select the pin for RX connected to the USB port      */
            .rxMode     = IfxPort_InputMode_pullUp,         /* RX pin                                               */
            .rts        = NULL_PTR,                         /* RTS pin not used                                     */
            .rtsMode    = IfxPort_OutputMode_pushPull,
            .tx         = &IfxAsclin1_TX_P15_0_OUT,         /* Select the pin for TX connected to the USB port      */
            .txMode     = IfxPort_OutputMode_pushPull,      /* TX pin                                               */
            .pinDriver  = IfxPort_PadDriver_cmosAutomotiveSpeed1
    };
    backupAscConf.pins = &backupPins;

    /* FIFO buffers configuration */
    backupAscConf.txBuffer = g_backupTxBuffer;                      /* Set the transmission buffer                          */
    backupAscConf.txBufferSize = ASC_TX_BUFFER_SIZE;              /* Set the transmission buffer size                     */
    backupAscConf.rxBuffer = g_backupRxBuffer;                      /* Set the receiving buffer                             */
    backupAscConf.rxBufferSize = ASC_RX_BUFFER_SIZE;              /* Set the receiving buffer size                        */

    /* Init ASCLIN module */
    IfxAsclin_Asc_initModule(&g_backup, &backupAscConf);          /* Initialize the module with the given configuration   */
}

/* Function to initialize ASCLIN module */
// Modify this to accomodate 2 different serial ports
void initSerialInterface(void)
{
    IfxAsclin_Asc_Config ascConf;

    /* Set default configurations */
    IfxAsclin_Asc_initModuleConfig(&ascConf, &MODULE_ASCLIN3); /* Initialize the structure with default values      */

    /* Set the desired baud rate */
    ascConf.baudrate.baudrate = ASC_BAUDRATE;                                   /* Set the baud rate in bit/s       */
    ascConf.baudrate.oversampling = IfxAsclin_OversamplingFactor_16;            /* Set the oversampling factor      */

    /* Configure the sampling mode */
    ascConf.bitTiming.medianFilter = IfxAsclin_SamplesPerBit_three;             /* Set the number of samples per bit*/
    ascConf.bitTiming.samplePointPosition = IfxAsclin_SamplePointPosition_8;    /* Set the first sample position    */

    /* ISR priorities and interrupt target */
    ascConf.interrupt.txPriority = ISR_PRIORITY_ASCLIN_TX;  /* Set the interrupt priority for TX events             */
    ascConf.interrupt.rxPriority = ISR_PRIORITY_ASCLIN_RX;  /* Set the interrupt priority for RX events             */
    ascConf.interrupt.erPriority = ISR_PRIORITY_ASCLIN_ER;  /* Set the interrupt priority for Error events          */
    ascConf.interrupt.typeOfService = IfxSrc_Tos_cpu0;

    /* Pin configuration */
    const IfxAsclin_Asc_Pins pins = {
            .cts        = NULL_PTR,                         /* CTS pin not used                                     */
            .ctsMode    = IfxPort_InputMode_pullUp,
            .rx         = &IfxAsclin3_RXD_P32_2_IN ,        /* Select the pin for RX connected to the USB port      */
            .rxMode     = IfxPort_InputMode_pullUp,         /* RX pin                                               */
            .rts        = NULL_PTR,                         /* RTS pin not used                                     */
            .rtsMode    = IfxPort_OutputMode_pushPull,
            .tx         = &IfxAsclin3_TX_P15_7_OUT,         /* Select the pin for TX connected to the USB port      */
            .txMode     = IfxPort_OutputMode_pushPull,      /* TX pin                                               */
            .pinDriver  = IfxPort_PadDriver_cmosAutomotiveSpeed1
    };
    ascConf.pins = &pins;

    /* FIFO buffers configuration */
    ascConf.txBuffer = g_uartTxBuffer;                      /* Set the transmission buffer                          */
    ascConf.txBufferSize = ASC_TX_BUFFER_SIZE;              /* Set the transmission buffer size                     */
    ascConf.rxBuffer = g_uartRxBuffer;                      /* Set the receiving buffer                             */
    ascConf.rxBufferSize = ASC_RX_BUFFER_SIZE;              /* Set the receiving buffer size                        */

    /* Init ASCLIN module */
    IfxAsclin_Asc_initModule(&g_asclin, &ascConf);          /* Initialize the module with the given configuration   */
}


void initBackupShell(void) {
    /* Initialize the hardware peripherals */

    //initPMM();

    initBackupInterface();

    /* Initialize the Standard Interface */
    IfxAsclin_Asc_stdIfDPipeInit(&g_ascBackupInterface, &g_backup);

    /* Initialize the Console */
    Ifx_Console_init(&g_ascBackupInterface);

    /* Print info to the console */
    printInfo(&g_ascBackupInterface);
    Ifx_Console_print(ENDLINE "Enter '" COMMAND_HELP "' to see the available commands" ENDLINE);

    /* Initialize the shell */
    Ifx_Shell_Config backupConf;
    Ifx_Shell_initConfig(&backupConf);                       /* Initialize the structure with default values         */

    backupConf.standardIo = &g_ascBackupInterface;         /* Set a pointer to the standard interface              */
    backupConf.commandList[0] = &g_backupCommands[0];         /* Set the supported command list                       */

    Ifx_Shell_init(&g_backupInterface, &backupConf);          /* Initialize the Shell with the given configuration    */
}

/* Function to initialize the Shell */
void initShellInterface(void)
{
    /* Initialize the hardware peripherals */

    //initPMM();

    initHSS();
    initSerialInterface();
    //initBackupInterface();

    /* Initialize the Standard Interface */
    IfxAsclin_Asc_stdIfDPipeInit(&g_ascStandardInterface, &g_asclin);

    /* Initialize the Console */
    Ifx_Console_init(&g_ascStandardInterface);

    /* Print info to the console */
    printInfo(&g_ascStandardInterface);
    Ifx_Console_print(ENDLINE "Enter '" COMMAND_HELP "' to see the available commands" ENDLINE);

    /* Initialize the shell */
    Ifx_Shell_Config shellConf;
    Ifx_Shell_initConfig(&shellConf);                       /* Initialize the structure with default values         */

    shellConf.standardIo = &g_ascStandardInterface;         /* Set a pointer to the standard interface              */
    shellConf.commandList[0] = &g_shellCommands[0];         /* Set the supported command list                       */

    Ifx_Shell_init(&g_shellInterface, &shellConf);          /* Initialize the Shell with the given configuration    */
}

void runBackupShell(void) {
    /* Process the received data */
    Ifx_Shell_process(&g_backupInterface);
}

/* Function to process the incoming received data */
void runShellInterface(void)
{
    /* Process the received data */
    Ifx_Shell_process(&g_shellInterface);
}
